Thanks to the following people for providing feedback and/or patches:

* Christopher Perkins         - chris \<at\> percious \<dot\> com
* oneirotekt                  - oneirotekt \<at\> zogblaster \<dot\> com
* Patrick Mézard              - patrick \<dot\> mezard \<at\> gmail \<dot\> com
* Stefan Schwendeler          - kungpfui \<at\> bierbuden \<dot\> de
* Helmut Jarausch             - jarausch \<at\> igpm.rwth-aachen \<dot\> de
* Nikolaus Rath               - nikolaus \<at\> rath \<dot\> org
* David Agnew                 - prescindor \<at\> gmail \<dot\> com
* Sofring Chow                - sofring912 \<at\> gmail \<dot\> com
* David Turon                 - turon.david \<at\> seznam \<dot\> cz
* Sofian Brabez               - sbz \<at\> freebsd \<dot\> org
* Ray Gardner                 - raygard \<at\> gmail \<dot\> com
* Federico                    - ipelupes \<at\> hotmail \<dot\> com
